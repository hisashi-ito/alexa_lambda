### Alexa SDK version1 の利用法
Alexa SDK version1を利用したAWS lambda 関数の設定方法
1. 本ディレクトリをzip 圧縮する
```
$ zip -r ../ask-sdk_1.zip *
```
1. AWS lambda 関数にzip圧縮したファイルを登録する
